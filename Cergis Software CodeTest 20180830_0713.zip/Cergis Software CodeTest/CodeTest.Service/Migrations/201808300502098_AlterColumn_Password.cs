namespace CodeTest.Service.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AlterColumn_Password : DbMigration
    {
        public override void Up()
        {
            RenameColumn("dbo.AspNetUsersPasswordsAudit", "PasswordHash", "Password");
            AlterColumn("dbo.AspNetUsersPasswordsAudit", "Password", c => c.String());
        }
        
        public override void Down()
        {
            RenameColumn("dbo.AspNetUsersPasswordsAudit", "Password", "PasswordHash");
        }
    }
}
