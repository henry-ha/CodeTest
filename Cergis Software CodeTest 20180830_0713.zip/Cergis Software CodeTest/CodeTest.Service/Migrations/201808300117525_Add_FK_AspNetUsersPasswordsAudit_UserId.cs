namespace CodeTest.Service.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Add_FK_AspNetUsersPasswordsAudit_UserId : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.AspNetUsersPasswordsAudit", "UserId", "dbo.AspNetUsers");
            DropIndex("dbo.AspNetUsersPasswordsAudit", new[] { "UserId" });
            AlterColumn("dbo.AspNetUsersPasswordsAudit", "UserId", c => c.String(maxLength: 128));
            CreateIndex("dbo.AspNetUsersPasswordsAudit", "UserId");
            AddForeignKey("dbo.AspNetUsersPasswordsAudit", "UserId", "dbo.AspNetUsers", "Id");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.AspNetUsersPasswordsAudit", "UserId", "dbo.AspNetUsers");
            DropIndex("dbo.AspNetUsersPasswordsAudit", new[] { "UserId" });
            AlterColumn("dbo.AspNetUsersPasswordsAudit", "UserId", c => c.String(nullable: false, maxLength: 128));
            CreateIndex("dbo.AspNetUsersPasswordsAudit", "UserId");
            AddForeignKey("dbo.AspNetUsersPasswordsAudit", "UserId", "dbo.AspNetUsers", "Id", cascadeDelete: true);
        }
    }
}
