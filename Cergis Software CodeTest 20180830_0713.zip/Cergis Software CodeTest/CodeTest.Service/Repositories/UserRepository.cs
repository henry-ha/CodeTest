﻿using System;
using System.Linq;
using NLog;

namespace CodeTest.Service.Repositories
{
    public class UserRepository
    {
        private CodeTestContext _context;
        private Logger logger = NLog.LogManager.GetCurrentClassLogger();

        public UserRepository()
        {
            CodeTestContext context = new CodeTestContext();
            this._context = context;
        }

        public User LoadByUserId(string id)
        {
            User user = null;
            try
            {
                if (!string.IsNullOrWhiteSpace(id))
                {
                    user = _context.Users
                        .Where(x => x.Id == id).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message + Environment.NewLine + ex.StackTrace);
                if (ex.InnerException != null)
                {
                    logger.Error(ex.InnerException.Message + Environment.NewLine + ex.InnerException.StackTrace);
                }
                throw;
            }

            return user;
        }
       
    }
}