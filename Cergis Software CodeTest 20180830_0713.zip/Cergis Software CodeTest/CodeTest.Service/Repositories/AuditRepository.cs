﻿using System;
using System.Collections.Generic;
using System.Linq;
using NLog;

namespace CodeTest.Service.Repositories
{
    public class AuditRepository
    {
        private CodeTestContext _context;
        private Logger logger = NLog.LogManager.GetCurrentClassLogger();

        public AuditRepository()
        {
            CodeTestContext context = new CodeTestContext();
            this._context = context;
        }

        public UserPasswordsAudit LoadById(int id)
        {
            UserPasswordsAudit item = null;
            if (id > 0)
            {
                try
                {
                    item = _context.UserPasswordsAudits
                            .Where(x => x.Id == id).FirstOrDefault();
                }
                catch (Exception ex)
                {
                    logger.Error(ex.Message + Environment.NewLine + ex.StackTrace);
                    if (ex.InnerException != null)
                    {
                        logger.Error(ex.InnerException.Message + Environment.NewLine + ex.InnerException.StackTrace);
                    }
                    throw;
                }                
            }

            return item;
        }
        
        public IEnumerable<UserPasswordsAudit> LoadByUserId(string id)
        {
            IEnumerable<UserPasswordsAudit> items;
            try
            {                
                items = _context.UserPasswordsAudits
                        .Where(x => x.User.Id == id)
                        .OrderBy(y => y.UpdateDateUTC);
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
                if (ex.InnerException != null)
                {
                    logger.Error(ex.InnerException.Message + Environment.NewLine + ex.InnerException.StackTrace);
                }
                throw;
            }            

            return items;
        }

        public bool InsertUserPasswordsAudit(UserPasswordsAudit item)
        {
            try
            {
                if (item != null && item.Id == 0)
                {
                    item.UpdateDateUTC = DateTime.UtcNow;
                    _context.Entry(item).State = System.Data.Entity.EntityState.Added;

                    _context.SaveChanges();

                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message + Environment.NewLine + ex.StackTrace);
                if (ex.InnerException != null)
                {
                    logger.Error(ex.InnerException.Message + Environment.NewLine + ex.InnerException.StackTrace);
                }
                throw;
            }            
        }

        public bool RemoveFromUserPasswordsAudit(UserPasswordsAudit item)
        {
            try
            {
                if (item != null && item.Id > 0)
                {
                    _context.UserPasswordsAudits.Remove(item);
                    _context.SaveChanges();

                    return true;
                } else
                {
                    return false;
                }            
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message + Environment.NewLine + ex.StackTrace);
                if (ex.InnerException != null)
                {
                    logger.Error(ex.InnerException.Message + Environment.NewLine + ex.InnerException.StackTrace);
                }
                throw;
            }
            
        }

        public string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }

        public string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }

    }
}