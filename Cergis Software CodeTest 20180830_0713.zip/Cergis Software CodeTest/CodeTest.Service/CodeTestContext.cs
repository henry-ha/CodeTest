﻿using System;
using System.Collections.Generic;
using System.Data.Entity;

public class CodeTestContext : BaseContext
{
    public CodeTestContext() : base("DefaultConnection")
    {
    }
}
