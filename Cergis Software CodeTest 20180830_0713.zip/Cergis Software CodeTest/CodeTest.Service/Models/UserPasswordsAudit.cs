﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

[Table("AspNetUsersPasswordsAudit")]
public class UserPasswordsAudit : BaseEntity<int>
{
    [Key]
    public override int Id { get; set; }

    [StringLength(255)]
    public string Password { get; set; }
    public DateTime UpdateDateUTC { get; set; }

    [StringLength(128)]
    public string UserId { get; set; }
    [ForeignKey("UserId")]
    public virtual User User { get; set; }
}
