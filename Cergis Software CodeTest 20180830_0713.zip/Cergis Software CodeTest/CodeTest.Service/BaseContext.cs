﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

public abstract class BaseContext : DbContext
{
    public BaseContext()
    {
    }

    protected BaseContext(string connString)
        :base(connString)
    {
    }
    
    public DbSet<UserPasswordsAudit> UserPasswordsAudits { get; set; }
    public DbSet<User> Users { get; set; }

    protected override void OnModelCreating(DbModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);        
    }    
}
