﻿using ClientDependency.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace Web
{
    public class MvcApplication : HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);

            // replaced BundleConfig with CreateBundles()
            //BundleConfig.RegisterBundles(BundleTable.Bundles);
            
            CreateBundles();
        }

        public static void CreateBundles()
        {
            BundleManager.CreateCssBundle("~/Content/css",
                new CssFile("~/Content/bootstrap.css"),
                new CssFile("~/Content/site.css"));

            BundleManager.CreateJsBundle("~/bundles/jquery",
                new JavascriptFile("~/Scripts/jquery-3.3.1.js")
                );

            BundleManager.CreateJsBundle("~/bundles/jqueryval",
                new JavascriptFile("~/Scripts/jquery.validate-vsdoc.js"),
                new JavascriptFile("~/Scripts/jquery.validate.js"));

            BundleManager.CreateJsBundle("~/bundles/modernizr",
                new JavascriptFile("~/Scripts/modernizr-2.8.3.js"));

            BundleManager.CreateJsBundle("~/bundles/bootstrap",
                new JavascriptFile("~/Scripts/bootstrap.js"));
        }
    }
}
