# Code Test - BackEnd #

## Scope: ##

1. Find the bugs and fix them (There may be no bugs at all)
2. Replace "BundleConfig" with ClientDepedecy  https://github.com/Shazwazza/ClientDependency
    * Remove unnecesety bundlerer configs and bindings
3. Extend user model and logic:
    * Add password change history (save only last 10 passwords, make sure saved passowrds are encrypted) 
    * Check when user try to change password that passwrd wasn't use in the past (make sure there are validation and display error messages in place).
    * Force user to change their password every 30 days.
4. Implement error log (do not use database to store error, please use txt file)


## Information ##

1. Please use the local database located in the App_Data folder. 

---
Henry's notes:

Bugs:
1.	Master page is not rendered so the Register/Login pages throws an error
2.	Introduced a build error where I created a project in .NET Framework 4.7.2 so had to upgrade Web project from 4.6.1 to 4.7.2 so it builds successfully

Package Manager Console instructions (creation of the new migration tables):
1.	From the �Default project:� dropdown list, select the Web project 
2.	Run the command update-database -force
3.	From the �Default project:� dropdown list, select the CodeTest.Service project 
4.	Run the command update-database -force

Error logging
1.	Using NLog to output exceptions to Text file



